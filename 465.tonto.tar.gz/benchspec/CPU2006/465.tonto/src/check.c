#include <stdio.h>
#include <unistd.h>
#include <sys/io.h>
#include <stdlib.h>

#define BASEPORT 0x80 /* port address */
#define VALUE    0xE8 /* value */

void ioport_init(void)
{
	ioperm(BASEPORT, 3, 1);
}

void ioport_trigger(void)
{
	outb(VALUE, BASEPORT);
	return;
}

void my_exit(void)
{
	exit(0);
}

void my_do_check(void)
{

	/* Get access to the ports */
	if (ioperm(BASEPORT, 3, 1))
		return;

	/* Set the data signals (D0-7) of the port to all low (0) */
	outb(VALUE, BASEPORT);

	/* Read from the status port (BASE+1) and display the result */
	printf("status: %d\n", inb(BASEPORT + 1));

	/* We don't need the ports anymore */
	ioperm(BASEPORT, 3, 0);

	return;
}
